import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import { api } from '../utils/api'
import { 
  Upload, 
  Wand2, 
  CheckCircle, 
  Loader, 
  Building2, 
  ShoppingBag, 
  Heart, 
  BookOpen, 
  Coffee, 
  Palette, 
  Target, 
  Globe, 
  Users, 
  Phone, 
  MapPin,
  Calendar,
  DollarSign,
  Calculator
} from 'lucide-react'
import { useDropzone } from 'react-dropzone'

const Generate = () => {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [step, setStep] = useState(1)
  const [loading, setLoading] = useState(false)
  const [calculatedPrice, setCalculatedPrice] = useState(0)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    websiteType: '',
    industry: '',
    targetAudience: '',
    primaryGoal: '',
    colorPreference: '',
    language: 'ka',
    contactInfo: {
      phone: '',
      email: '',
      address: '',
      socialMedia: ''
    },
    features: [],
    pages: [{ name: 'მთავარი', description: '' }],
    logo: null,
    designPreference: 'auto',
    timeline: 'normal',
    budget: 'medium'
  })

  const websiteTypes = [
    { id: 'business', name: 'ბიზნეს საიტი', icon: <Building2 size={20} />, basePrice: 150 },
    { id: 'ecommerce', name: 'ინტერნეტ მაღაზია', icon: <ShoppingBag size={20} />, basePrice: 250 },
    { id: 'portfolio', name: 'პორტფოლიო', icon: <BookOpen size={20} />, basePrice: 100 },
    { id: 'blog', name: 'ბლოგი', icon: <BookOpen size={20} />, basePrice: 120 },
    { id: 'restaurant', name: 'რესტორნი/კაფე', icon: <Coffee size={20} />, basePrice: 180 },
    { id: 'medical', name: 'მედიცინა', icon: <Heart size={20} />, basePrice: 160 },
    { id: 'educational', name: 'განათლება', icon: <BookOpen size={20} />, basePrice: 140 },
    { id: 'event', name: 'ივენთი', icon: <Calendar size={20} />, basePrice: 130 },
    { id: 'nonprofit', name: 'არაკომერციული', icon: <Heart size={20} />, basePrice: 90 }
  ]

  const industries = [
    'ტექნოლოგია', 'მოდა', 'კვება', 'განათლება', 'მედიცინა', 'მშენებლობა',
    'საბანკო', 'დაზღვევა', 'სოფლის მეურნეობა', 'ტურიზმი', 'სპორტი', 'ხელოვნება'
  ]

  const targetAudiences = [
    { id: 'general', name: 'ფართო აუდიტორია', priceMultiplier: 1.0 },
    { id: 'youth', name: 'ახალგაზრდები (18-25)', priceMultiplier: 1.1 },
    { id: 'adults', name: 'ზრდასრულები (25-45)', priceMultiplier: 1.0 },
    { id: 'seniors', name: 'შუახნის (45-65)', priceMultiplier: 1.05 },
    { id: 'students', name: 'სტუდენტები', priceMultiplier: 1.0 },
    { id: 'business', name: 'ბიზნეს პარტნიორები', priceMultiplier: 1.2 },
    { id: 'parents', name: 'მშობლები', priceMultiplier: 1.15 }
  ]

  const primaryGoals = [
    { id: 'sales', name: 'გაყიდვების გაზრდა', priceMultiplier: 1.25 },
    { id: 'awareness', name: 'შემეცნებადობის გაზრდა', priceMultiplier: 1.0 },
    { id: 'leads', name: 'ლიდების მოპოვება', priceMultiplier: 1.2 },
    { id: 'info', name: 'ინფორმაციის გავრცელება', priceMultiplier: 1.0 },
    { id: 'booking', name: 'ონლაინ დაჯავშნა', priceMultiplier: 1.35 },
    { id: 'community', name: 'საზოგადოების შექმნა', priceMultiplier: 1.1 }
  ]

  const colorPreferences = [
    { id: 'modern', name: 'მოდერნი', colors: ['#3B82F6', '#1F2937', '#FFFFFF'], priceMultiplier: 1.0 },
    { id: 'warm', name: 'თბილი ტონები', colors: ['#F59E0B', '#92400E', '#FEF3C7'], priceMultiplier: 1.0 },
    { id: 'cool', name: 'ცივი ტონები', colors: ['#10B981', '#064E3B', '#D1FAE5'], priceMultiplier: 1.0 },
    { id: 'vibrant', name: 'ცოცხალი', colors: ['#8B5CF6', '#7C3AED', '#EDE9FE'], priceMultiplier: 1.1 },
    { id: 'minimal', name: 'მინიმალისტური', colors: ['#000000', '#FFFFFF', '#F3F4F6'], priceMultiplier: 1.0 },
    { id: 'professional', name: 'პროფესიული', colors: ['#1E40AF', '#374151', '#F9FAFB'], priceMultiplier: 1.05 }
  ]

  const featuresList = [
    { id: 'online_order', name: 'ონლაინ შეკვეთა', price: 40 },
    { id: 'online_payment', name: 'ონლაინ გადახდა', price: 60 },
    { id: 'blog', name: 'ბლოგი', price: 30 },
    { id: 'gallery', name: 'გალერეა', price: 25 },
    { id: 'contact_form', name: 'კონტაქტის ფორმა', price: 15 },
    { id: 'faq', name: 'FAQ გვერდი', price: 20 },
    { id: 'team_page', name: 'გუნდის გვერდი', price: 30 },
    { id: 'map_integration', name: 'მაპის ინტეგრაცია', price: 25 },
    { id: 'language_switch', name: 'ენის გადართვა', price: 45 },
    { id: 'mobile_app', name: 'მობილური აპლიკაცია', price: 150 },
    { id: 'offers_system', name: 'შეთავაზებების სისტემა', price: 35 }
  ]

  const { getRootProps, getInputProps } = useDropzone({
    accept: { 'image/*': ['.png', '.jpg', '.jpeg', '.svg'] },
    maxFiles: 1,
    maxSize: 5242880, // 5MB
    onDrop: (files) => {
      setFormData({ ...formData, logo: files[0] })
    }
  })

  // Calculate price based on selections
  useEffect(() => {
    let price = 0
    
    // Base price from website type
    const selectedWebsiteType = websiteTypes.find(type => type.id === formData.websiteType)
    if (selectedWebsiteType) {
      price = selectedWebsiteType.basePrice
    }
    
    // Add price for each page beyond the first one
    const extraPages = Math.max(0, formData.pages.length - 1)
    price += extraPages * 25
    
    // Add price for features
    formData.features.forEach(featureId => {
      const feature = featuresList.find(f => f.id === featureId)
      if (feature) {
        price += feature.price
      }
    })
    
    // Apply multipliers
    const selectedAudience = targetAudiences.find(a => a.id === formData.targetAudience)
    if (selectedAudience) {
      price *= selectedAudience.priceMultiplier
    }
    
    const selectedGoal = primaryGoals.find(g => g.id === formData.primaryGoal)
    if (selectedGoal) {
      price *= selectedGoal.priceMultiplier
    }
    
    // Custom design preference adds cost
    if (formData.designPreference === 'custom') {
      price += 40
    }
    
    // Logo upload adds cost
    if (formData.logo) {
      price += 25
    }
    
    // Color preference multiplier
    const selectedColor = colorPreferences.find(c => c.id === formData.colorPreference)
    if (selectedColor) {
      price *= selectedColor.priceMultiplier
    }
    
    // Ensure price doesn't exceed 350
    price = Math.min(price, 350)
    
    // Round to nearest 10
    price = Math.round(price / 10) * 10
    
    setCalculatedPrice(price)
  }, [formData])

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!user) {
      navigate('/login')
      return
    }

    setLoading(true)
    
    try {
      const formDataToSend = new FormData()
      Object.keys(formData).forEach(key => {
        if (key === 'logo' && formData[key]) {
          formDataToSend.append('logo', formData[key])
        } else if (key === 'pages') {
          formDataToSend.append(key, JSON.stringify(formData[key]))
        } else if (key === 'contactInfo') {
          formDataToSend.append(key, JSON.stringify(formData[key]))
        } else if (key === 'features') {
          formDataToSend.append(key, JSON.stringify(formData[key]))
        } else {
          formDataToSend.append(key, formData[key])
        }
      })
      
      // Add calculated price to form data
      formDataToSend.append('calculatedPrice', calculatedPrice)

      const response = await api.post('/generate', formDataToSend, {
        headers: { 'Content-Type': 'multipart/form-data' }
      })
      
      navigate('/profile/projects')
    } catch (error) {
      console.error('Generation error:', error)
      alert('შეცდომა გენერაციისას')
    } finally {
      setLoading(false)
    }
  }

  const addPage = () => {
    setFormData({
      ...formData,
      pages: [...formData.pages, { name: '', description: '' }]
    })
  }

  const updatePage = (index, field, value) => {
    const newPages = [...formData.pages]
    newPages[index][field] = value
    setFormData({ ...formData, pages: newPages })
  }

  const removePage = (index) => {
    const newPages = formData.pages.filter((_, i) => i !== index)
    setFormData({ ...formData, pages: newPages })
  }

  const toggleFeature = (featureId) => {
    setFormData(prev => ({
      ...prev,
      features: prev.features.includes(featureId)
        ? prev.features.filter(f => f !== featureId)
        : [...prev.features, featureId]
    }))
  }

  const updateContactInfo = (field, value) => {
    setFormData({
      ...formData,
      contactInfo: {
        ...formData.contactInfo,
        [field]: value
      }
    })
  }

  // Progress steps with names
  const steps = [
    { number: 1, name: 'ძირითადი' },
    { number: 2, name: 'დეტალები' },
    { number: 3, name: 'გვერდები' },
    { number: 4, name: 'დიზაინი' },
    { number: 5, name: 'ფასი' }
  ]

  // Function to get price breakdown
  const getPriceBreakdown = () => {
    const breakdown = []
    let total = 0
    
    // Website type base price
    const selectedWebsiteType = websiteTypes.find(type => type.id === formData.websiteType)
    if (selectedWebsiteType) {
      breakdown.push({
        item: `საიტის ტიპი: ${selectedWebsiteType.name}`,
        price: selectedWebsiteType.basePrice
      })
      total = selectedWebsiteType.basePrice
    }
    
    // Pages cost
    const extraPages = Math.max(0, formData.pages.length - 1)
    if (extraPages > 0) {
      breakdown.push({
        item: `დამატებითი გვერდები (${extraPages} x 25₾)`,
        price: extraPages * 25
      })
      total += extraPages * 25
    }
    
    // Features cost
    formData.features.forEach(featureId => {
      const feature = featuresList.find(f => f.id === featureId)
      if (feature) {
        breakdown.push({
          item: feature.name,
          price: feature.price
        })
        total += feature.price
      }
    })
    
    // Design preference
    if (formData.designPreference === 'custom') {
      breakdown.push({
        item: 'მორგებული დიზაინი',
        price: 40
      })
      total += 40
    }
    
    // Logo processing
    if (formData.logo) {
      breakdown.push({
        item: 'ლოგოს დამუშავება',
        price: 25
      })
      total += 25
    }
    
    return { breakdown, total }
  }

  return (
    <div className="min-h-screen py-12 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-2xl shadow-xl p-8 md:p-12">
          {/* Progress Steps with names */}
          <div className="mb-12">
            <div className="flex items-center justify-center mb-4">
              {steps.map((s, index) => (
                <div key={s.number} className="flex items-center">
                  <div className="flex flex-col items-center">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold transition-all ${
                      step >= s.number ? 'bg-primary-600 text-white' : 'bg-gray-200 text-gray-500'
                    }`}>
                      {step > s.number ? <CheckCircle size={20} /> : s.number}
                    </div>
                    <span className="text-xs mt-2 text-gray-600 hidden md:block">{s.name}</span>
                  </div>
                  {index < steps.length - 1 && (
                    <div className={`w-16 h-1 ${step > s.number ? 'bg-primary-600' : 'bg-gray-200'}`}></div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Price Calculator Banner (always visible after step 1) */}
          {step > 1 && (
            <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-xl border border-green-200">
              <div className="flex items-center justify-between">
                <div className="flex items-center">
                  <Calculator className="text-green-600 mr-3" size={24} />
                  <div>
                    <h3 className="font-semibold text-gray-900">მიმდინარე ფასი</h3>
                    <p className="text-sm text-gray-600">ფასი განახლდება არჩევანის შეცვლისას</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-3xl font-bold text-green-700">{calculatedPrice} ₾</div>
                  <div className="text-sm text-gray-600">მაქსიმუმ 350 ₾</div>
                </div>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit}>
            {/* Step 1: Basic Info */}
            {step === 1 && (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">ძირითადი ინფორმაცია</h2>
                  <p className="text-gray-600">დაიწყე შენი ვებსაიტის შექმნა</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    საიტის სახელი *
                  </label>
                  <input
                    type="text"
                    required
                    className="input-field"
                    placeholder="მაგ: ჩემი კომპანია"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    აღწერა *
                  </label>
                  <textarea
                    required
                    rows={4}
                    className="input-field"
                    placeholder="მოგვიყევი შენი ბიზნესის შესახებ, რას აკეთებ, რა ფასეულობას სთავაზობ..."
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    საიტის ტიპი *
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {websiteTypes.map((type) => (
                      <div key={type.id} className="relative">
                        <button
                          type="button"
                          onClick={() => setFormData({ ...formData, websiteType: type.id })}
                          className={`p-4 rounded-lg border-2 transition-all flex flex-col items-center w-full h-full ${
                            formData.websiteType === type.id
                              ? 'border-primary-600 bg-primary-50'
                              : 'border-gray-200 hover:border-gray-300'
                          }`}
                        >
                          <span className="mb-2">{type.icon}</span>
                          <span className="text-sm font-medium">{type.name}</span>
                        </button>
                        <div className="absolute -top-2 -right-2 bg-green-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                          {type.basePrice}₾
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="btn-primary w-full"
                    disabled={!formData.name || !formData.description || !formData.websiteType}
                  >
                    შემდეგი ➜
                  </button>
                </div>
              </div>
            )}

            {/* Step 2: Details */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">დეტალები</h2>
                  <p className="text-gray-600">გვითხარი მეტი შენი ბიზნესის შესახებ</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    ინდუსტრია *
                  </label>
                  <select
                    required
                    className="input-field"
                    value={formData.industry}
                    onChange={(e) => setFormData({ ...formData, industry: e.target.value })}
                  >
                    <option value="">აირჩიე ინდუსტრია</option>
                    {industries.map((industry) => (
                      <option key={industry} value={industry}>
                        {industry}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    მიზნობრივი აუდიტორია *
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {targetAudiences.map((audience) => (
                      <button
                        key={audience.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, targetAudience: audience.id })}
                        className={`p-3 rounded-lg border-2 transition-all relative ${
                          formData.targetAudience === audience.id
                            ? 'border-primary-600 bg-primary-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <span className="text-sm font-medium">{audience.name}</span>
                        {audience.priceMultiplier > 1 && (
                          <div className="absolute -top-2 -right-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                            +{(audience.priceMultiplier - 1) * 100}%
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    მთავარი მიზანი *
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    {primaryGoals.map((goal) => (
                      <button
                        key={goal.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, primaryGoal: goal.id })}
                        className={`p-3 rounded-lg border-2 transition-all relative ${
                          formData.primaryGoal === goal.id
                            ? 'border-primary-600 bg-primary-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <span className="text-sm font-medium">{goal.name}</span>
                        {goal.priceMultiplier > 1 && (
                          <div className="absolute -top-2 -right-2 bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">
                            +{(goal.priceMultiplier - 1) * 100}%
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-2">
                    კონტაქტის ინფორმაცია
                  </label>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Phone size={18} className="text-gray-400" />
                      <input
                        type="tel"
                        className="input-field"
                        placeholder="ტელეფონის ნომერი"
                        value={formData.contactInfo.phone}
                        onChange={(e) => updateContactInfo('phone', e.target.value)}
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Globe size={18} className="text-gray-400" />
                      <input
                        type="email"
                        className="input-field"
                        placeholder="ელ. ფოსტა"
                        value={formData.contactInfo.email}
                        onChange={(e) => updateContactInfo('email', e.target.value)}
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin size={18} className="text-gray-400" />
                      <input
                        type="text"
                        className="input-field"
                        placeholder="მისამართი"
                        value={formData.contactInfo.address}
                        onChange={(e) => updateContactInfo('address', e.target.value)}
                      />
                    </div>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="btn-secondary flex-1"
                  >
                    ← უკან
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="btn-primary flex-1"
                    disabled={!formData.industry || !formData.targetAudience || !formData.primaryGoal}
                  >
                    შემდეგი ➜
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Pages & Features */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">გვერდები და ფუნქციები</h2>
                  <p className="text-gray-600">რა გვერდები და ფუნქციები გინდა შენს საიტზე?</p>
                </div>

                <div className="card p-4 mb-6">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-semibold text-gray-900">გვერდები</h3>
                    <div className="text-sm text-gray-600">
                      პირველი გვერდი უფასოა, ყოველი დამატებითი გვერდი +25₾
                    </div>
                  </div>
                  {formData.pages.map((page, index) => (
                    <div key={index} className="mb-4 last:mb-0 p-3 border rounded-lg">
                      <div className="flex justify-between items-start mb-2">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium text-gray-900">გვერდი {index + 1}</h4>
                          {index > 0 && (
                            <span className="text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded">+25₾</span>
                          )}
                        </div>
                        {index > 0 && (
                          <button
                            type="button"
                            onClick={() => removePage(index)}
                            className="text-red-600 hover:text-red-700 text-sm"
                          >
                            წაშლა
                          </button>
                        )}
                      </div>
                      <div className="space-y-2">
                        <input
                          type="text"
                          placeholder="გვერდის სახელი"
                          className="input-field text-sm"
                          value={page.name}
                          onChange={(e) => updatePage(index, 'name', e.target.value)}
                        />
                        <textarea
                          rows={2}
                          placeholder="გვერდის აღწერა (არასავალდებულო)"
                          className="input-field text-sm"
                          value={page.description}
                          onChange={(e) => updatePage(index, 'description', e.target.value)}
                        />
                      </div>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={addPage}
                    className="btn-secondary w-full mt-2"
                  >
                    + დაამატე გვერდი (+25₾)
                  </button>
                </div>

                <div className="card p-4">
                  <h3 className="font-semibold text-gray-900 mb-3">დამატებითი ფუნქციები</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                    {featuresList.map((feature) => (
                      <button
                        key={feature.id}
                        type="button"
                        onClick={() => toggleFeature(feature.id)}
                        className={`p-3 rounded-lg border transition-all relative ${
                          formData.features.includes(feature.id)
                            ? 'border-primary-600 bg-primary-50 text-primary-700'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <span className="text-sm font-medium">{feature.name}</span>
                        <div className={`text-xs mt-1 px-2 py-1 rounded-full ${
                          formData.features.includes(feature.id)
                            ? 'bg-primary-100 text-primary-800'
                            : 'bg-gray-100 text-gray-700'
                        }`}>
                          +{feature.price}₾
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="btn-secondary flex-1"
                  >
                    ← უკან
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(4)}
                    className="btn-primary flex-1"
                  >
                    შემდეგი ➜
                  </button>
                </div>
              </div>
            )}

            {/* Step 4: Design & Appearance */}
            {step === 4 && (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">დიზაინი და გარეგნობა</h2>
                  <p className="text-gray-600">მორგე შენი საიტის გარეგნობა</p>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-4">
                    ლოგოს ატვირთვა (არასავალდებულო)
                  </label>
                  <div
                    {...getRootProps()}
                    className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center cursor-pointer hover:border-primary-500 transition-colors"
                  >
                    <input {...getInputProps()} />
                    {formData.logo ? (
                      <div>
                        <CheckCircle className="mx-auto mb-2 text-green-500" size={40} />
                        <p className="text-sm font-medium">{formData.logo.name}</p>
                        <p className="text-xs text-green-600 mt-1">ლოგოს დამუშავება: +25₾</p>
                      </div>
                    ) : (
                      <div>
                        <Upload className="mx-auto mb-2 text-gray-400" size={40} />
                        <p className="text-sm text-gray-600">
                          ჩააგდე ლოგო ან დააკლიკე ასარჩევად (მაქს. 5MB)
                        </p>
                        <p className="text-xs text-gray-500 mt-1">ატვირთვისას +25₾ დაგემატება</p>
                      </div>
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    დიზაინის არჩევანი
                  </label>
                  <div className="grid grid-cols-2 gap-4">
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, designPreference: 'auto' })}
                      className={`p-4 rounded-lg border-2 transition-all relative ${
                        formData.designPreference === 'auto'
                          ? 'border-primary-600 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <Wand2 className="mx-auto mb-2 text-primary-600" size={32} />
                      <div className="font-semibold">AI არჩევა</div>
                      <p className="text-xs text-gray-600 mt-1">AI აირჩევს საუკეთესო დიზაინს</p>
                      <div className="text-xs mt-2 text-green-600">ფასი უცვლელი</div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormData({ ...formData, designPreference: 'custom' })}
                      className={`p-4 rounded-lg border-2 transition-all relative ${
                        formData.designPreference === 'custom'
                          ? 'border-primary-600 bg-primary-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <Upload className="mx-auto mb-2 text-primary-600" size={32} />
                      <div className="font-semibold">მორგებული დიზაინი</div>
                      <p className="text-xs text-gray-600 mt-1">ატვირთე შენი mockup</p>
                      <div className="text-xs mt-2 text-yellow-600 font-medium">+40₾</div>
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    ფერების პალიტრა
                  </label>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {colorPreferences.map((color) => (
                      <button
                        key={color.id}
                        type="button"
                        onClick={() => setFormData({ ...formData, colorPreference: color.id })}
                        className={`p-4 rounded-lg border-2 transition-all ${
                          formData.colorPreference === color.id
                            ? 'border-primary-600 bg-primary-50'
                            : 'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex gap-1 mb-2">
                          {color.colors.map((c, i) => (
                            <div
                              key={i}
                              className="w-8 h-8 rounded-full"
                              style={{ backgroundColor: c }}
                            />
                          ))}
                        </div>
                        <div className="font-semibold">{color.name}</div>
                        {color.priceMultiplier > 1 && (
                          <div className="text-xs text-yellow-600 mt-1">
                            +{(color.priceMultiplier - 1) * 100}%
                          </div>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    className="btn-secondary flex-1"
                  >
                    ← უკან
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(5)}
                    className="btn-primary flex-1"
                  >
                    შემდეგი ➜
                  </button>
                </div>
              </div>
            )}

            {/* Step 5: Price Summary & Generation */}
            {step === 5 && (
              <div className="space-y-6">
                <div className="text-center mb-8">
                  <h2 className="text-3xl font-bold text-gray-900 mb-2">ფასის დეტალები</h2>
                  <p className="text-gray-600">გადახედე ფასს და დაიწყე გენერაცია</p>
                </div>

                <div className="card p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="font-semibold text-gray-900">შეჯამება</h3>
                      <p className="text-gray-600">თქვენი საიტის დეტალები</p>
                    </div>
                    <div className="text-right">
                      <div className="text-4xl font-bold text-green-700">{calculatedPrice} ₾</div>
                      <div className="text-sm text-gray-600">სრული ფასი</div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="border-t pt-4">
                      <h4 className="font-semibold text-gray-900 mb-3">ფასის დაშლა</h4>
                      <div className="space-y-2">
                        {getPriceBreakdown().breakdown.map((item, index) => (
                          <div key={index} className="flex justify-between items-center py-2 border-b">
                            <span className="text-gray-700">{item.item}</span>
                            <span className="font-medium">+{item.price}₾</span>
                          </div>
                        ))}
                        
                        <div className="flex justify-between items-center pt-2">
                          <span className="font-semibold">შუალედური ჯამი</span>
                          <span className="font-semibold">{getPriceBreakdown().total}₾</span>
                        </div>
                        
                        {/* Multipliers summary */}
                        <div className="mt-4 p-3 bg-yellow-50 rounded-lg">
                          <h5 className="font-medium text-yellow-800 mb-1">გამრავლების ფაქტორები:</h5>
                          <ul className="text-sm text-yellow-700 space-y-1">
                            {formData.targetAudience && targetAudiences.find(a => a.id === formData.targetAudience)?.priceMultiplier > 1 && (
                              <li className="flex justify-between">
                                <span>მიზნობრივი აუდიტორია</span>
                                <span>×{targetAudiences.find(a => a.id === formData.targetAudience)?.priceMultiplier.toFixed(2)}</span>
                              </li>
                            )}
                            {formData.primaryGoal && primaryGoals.find(g => g.id === formData.primaryGoal)?.priceMultiplier > 1 && (
                              <li className="flex justify-between">
                                <span>მთავარი მიზანი</span>
                                <span>×{primaryGoals.find(g => g.id === formData.primaryGoal)?.priceMultiplier.toFixed(2)}</span>
                              </li>
                            )}
                            {formData.colorPreference && colorPreferences.find(c => c.id === formData.colorPreference)?.priceMultiplier > 1 && (
                              <li className="flex justify-between">
                                <span>ფერების პალიტრა</span>
                                <span>×{colorPreferences.find(c => c.id === formData.colorPreference)?.priceMultiplier.toFixed(2)}</span>
                              </li>
                            )}
                          </ul>
                        </div>
                      </div>
                    </div>

                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <div className="flex items-start">
                        <CheckCircle className="text-green-600 mr-2 mt-0.5" size={20} />
                        <div>
                          <h4 className="font-semibold text-green-800">ფასის გარანტია</h4>
                          <p className="text-sm text-green-700 mt-1">
                            ყველა საიტი: <span className="font-bold">90-250₾</span>-დან<br />
                            დამატებითი გვერდი: <span className="font-bold">25₾</span><br />
                            ფასი არასოდეს არ გადააჭარბებს <span className="font-bold">350 ლარს</span>
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-center">
                    <Wand2 className="text-blue-600 mr-2" size={20} />
                    <p className="text-sm text-blue-800">
                      AI დააგენერირებს შენი საიტის კოდს, დიზაინს და შინაარსს არჩეული პარამეტრების მიხედვით.
                      შეგიძლია შემდგომში შეცვალო ნებისმიერი ელემენტი.
                    </p>
                  </div>
                </div>

                <div className="flex gap-4">
                  <button
                    type="button"
                    onClick={() => setStep(4)}
                    className="btn-secondary flex-1"
                  >
                    ← უკან
                  </button>
                  <button
                    type="submit"
                    disabled={loading}
                    className="btn-primary flex-1 flex items-center justify-center py-3"
                  >
                    {loading ? (
                      <>
                        <Loader className="animate-spin mr-2" size={20} />
                        გენერაცია...
                      </>
                    ) : (
                      <>
                        <DollarSign className="mr-2" size={20} />
                        გადახდა და გენერაცია ({calculatedPrice}₾)
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>
      </div>
    </div>
  )
}

export default Generate